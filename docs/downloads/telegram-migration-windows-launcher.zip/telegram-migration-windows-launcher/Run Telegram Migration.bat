@echo off
setlocal EnableExtensions
 title Telegram Migration
 color 0B

rem Run from the folder containing this launcher and its .env file.
pushd "%~dp0" >nul

 echo.
 echo  ============================================================
 echo     TELEGRAM DESKTOP CHAT MIGRATION
 echo  ============================================================
 echo.
 echo  This launcher migrates a Telegram Desktop export and its
 echo  accompanying media folders to a channel using your bot.
 echo.
 echo  It does not sign in to your personal Telegram account.
 echo.

rem Create a local environment file on first run, then let the user edit it.
if not exist ".env" (
    if exist ".env.example" (
        copy /y ".env.example" ".env" >nul
    ) else (
        echo ERROR: .env.example is missing from this folder.
        echo Keep the launcher and its companion files together.
        echo.
        pause
        popd >nul
        exit /b 1
    )
    echo First-time setup: opening .env in Notepad.
    echo Replace every example value with your own Telegram credentials.
    echo Save the file, close Notepad, and double-click this launcher again.
    echo.
    start "" notepad.exe "%CD%\.env"
    pause
    popd >nul
    exit /b 0
)

rem Find a Python 3 interpreter (3.10 or newer).
set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 (
    py -3 --version >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 (
        python --version >nul 2>nul
        if not errorlevel 1 set "PYTHON_CMD=python"
    )
)
if not defined PYTHON_CMD (
    echo ERROR: Python 3.10 or newer was not found.
    echo Install Python from https://www.python.org/downloads/windows/
    echo Then double-click this launcher again.
    echo.
    pause
    popd >nul
    exit /b 1
)

%PYTHON_CMD% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
    echo ERROR: Python 3.10 or newer is required.
    echo The interpreter found by Windows is too old.
    echo.
    pause
    popd >nul
    exit /b 1
)

rem Create an isolated virtual environment beside the launcher.
if not exist ".venv\Scripts\python.exe" (
    echo Creating a private Python environment for Telegram Migration...
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 goto :python_error
)
set "VENV_PY=%CD%\.venv\Scripts\python.exe"

rem Install the PyPI package only when it is not already installed here.
"%VENV_PY%" -c "import telegram_migration" >nul 2>nul
if errorlevel 1 (
    echo Installing Telegram Migration and its dependencies from PyPI...
    "%VENV_PY%" -m pip install --upgrade pip
    if errorlevel 1 goto :install_error
    "%VENV_PY%" -m pip install telegram-migration
    if errorlevel 1 goto :install_error
)

rem Let the user choose the complete Telegram Desktop export directory.
echo Select the folder containing messages.html and the exported media folders.
echo Keep photos, video_files, files, voice_messages and other media folders together.
echo.
set "EXPORT_DIR="
for /f "usebackq delims=" %%D in (`powershell -NoProfile -STA -Command "Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = 'Select the Telegram Desktop export folder (messages.html and media folders)'; $d.ShowNewFolderButton = $false; if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $d.SelectedPath }" 2^>nul`) do set "EXPORT_DIR=%%D"

if not defined EXPORT_DIR (
    echo No folder was selected in the dialog.
    set /p "EXPORT_DIR=Paste the full path to your Telegram export folder (or press Enter to cancel): "
)
if not defined EXPORT_DIR goto :cancelled

if not exist "%EXPORT_DIR%\" (
    echo ERROR: That folder does not exist:
    echo "%EXPORT_DIR%"
    echo.
    pause
    popd >nul
    exit /b 1
)

dir /b /a-d "%EXPORT_DIR%\messages*.html" >nul 2>nul
if errorlevel 1 (
    echo ERROR: No messages.html or messages2.html export page was found.
    echo Choose the folder that contains the HTML pages, not an individual media folder.
    echo.
    pause
    popd >nul
    exit /b 1
)

echo.
echo  ------------------------------------------------------------
echo  STEP 1: DRY-RUN PREVIEW
echo  ------------------------------------------------------------
echo Nothing will be sent during this preview.
echo.
"%VENV_PY%" -m telegram_migration --env-file "%CD%\.env" --export-dir "%EXPORT_DIR%" --dry-run
if errorlevel 1 goto :run_error

echo.
echo  ------------------------------------------------------------
echo  STEP 2: ACTUAL MIGRATION
echo  ------------------------------------------------------------
echo Review the preview above before continuing.
echo The program will ask you to confirm the destination channel.
echo Progress files will be stored in the selected export folder.
echo.
set "SEND_NOW="
set /p "SEND_NOW=Type YES to start sending messages and media, or press Enter to stop: "
if /I not "%SEND_NOW%"=="YES" goto :cancelled

echo.
echo Starting the migration...
echo.
"%VENV_PY%" -m telegram_migration --env-file "%CD%\.env" --export-dir "%EXPORT_DIR%" --send
set "RUN_RESULT=%ERRORLEVEL%"
if not "%RUN_RESULT%"=="0" goto :run_error

echo.
echo Migration process finished. Check the summary above and keep the progress files.
echo Run this launcher again to resume an interrupted migration.
echo.
pause
popd >nul
exit /b 0

:python_error
echo.
echo ERROR: Could not create the local Python environment.
echo Check that Python 3.10 or newer is installed correctly.
goto :fatal

:install_error
echo.
echo ERROR: The package could not be installed from PyPI.
echo Check your internet connection, then try again.
goto :fatal

:run_error
echo.
echo The command reported an error. Read the message above before trying again.
echo If this happened during sending, some messages may already have reached
echo the destination. Keep the progress files and review them before retrying.
echo.
pause
popd >nul
exit /b 1

:cancelled
echo.
echo Cancelled. No migration was started by this launcher.
echo.
pause
popd >nul
exit /b 0

:fatal
 echo.
 pause
 popd >nul
 exit /b 1
